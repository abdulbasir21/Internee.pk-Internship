// Seeds a handful of predefined courses (mix of free + premium) so the
// home screen has content on first run.
// Run AFTER adminSeed.js — courses need an existing Admin as createdBy.
// Run with: node seed.js  (or  npm run seed)

require('dotenv').config();
const connectDB = require('./config/db');
const User = require('./models/User');
const Course = require('./models/Course');

const sampleCourses = [
  {
    title: 'JavaScript Basics',
    description: 'A friendly introduction to variables, functions, and control flow.',
    category: 'Programming',
    price: 0,
    isFree: true,
    previewImage: 'https://example.com/images/js-basics.png',
    content: [
      'JavaScript is the language of the web, and every browser on the planet can run it without any extra setup. In this lesson we start from the very beginning: what a variable is, how to declare one with let or const, and why modern JavaScript avoids var in favor of these two keywords.',
      'Functions are the building blocks of any real program. You will learn how to write a function, pass arguments into it, and return a value out of it. We will also cover arrow functions, a shorter syntax that has become the default style in most codebases today.',
      'Control flow is how a program makes decisions. We will walk through if/else statements, switch statements, and the three most common loops — for, while, and for...of — with small runnable examples for each so the logic sticks.',
      'No language lesson is complete without talking about data structures. This section introduces arrays and objects, the two containers you will reach for constantly, along with a handful of the array methods (map, filter, reduce) that make everyday tasks much shorter to write.',
      'By the end of this course you will be comfortable reading a short JavaScript file top to bottom and predicting what it does. The next course in this track, Advanced Node.js & Express, picks up exactly where this one leaves off.',
    ],
  },
  {
    title: 'Advanced Node.js & Express',
    description: 'Build production-ready APIs with Node.js, Express, and MongoDB.',
    category: 'Programming',
    price: 49,
    isFree: false,
    previewImage: 'https://example.com/images/advanced-node.png',
    content: [
      'Node.js lets you run JavaScript outside the browser, which makes it a natural choice for building backend APIs. We open with how the Node runtime and its event loop work, and why that model is so good at handling many requests at once.',
      'Express is the framework almost every Node API is built on. You will learn how routing works, how middleware chains requests through your app, and how to organize routes, controllers, and models so a project stays maintainable as it grows.',
      'Talking to a database is where most real APIs spend their time. We connect Express to MongoDB using Mongoose, define schemas with validation, and write the create, read, update, and delete operations that power almost any application.',
      'Authentication is covered in depth: hashing passwords safely, issuing JSON Web Tokens on login, and writing middleware that protects routes so only logged-in — or admin — users can reach them.',
      'The course closes with production concerns: environment variables, error handling middleware, and a short section on deploying your API so it is reachable from the outside world.',
    ],
  },
  {
    title: 'Intro to UI/UX Design',
    description: 'Learn the fundamentals of user-centered design.',
    category: 'Design',
    price: 0,
    isFree: true,
    previewImage: 'https://example.com/images/ui-ux-intro.png',
    content: [
      'Good design starts with the user, not the interface. This course opens by explaining the difference between UI (how a product looks) and UX (how a product feels to use), and why the best products treat both as one discipline.',
      'We cover the design process end to end: research, wireframing, prototyping, and testing. Each stage gets a short, practical explanation of what it produces and why skipping it tends to cost you more time later.',
      'Visual fundamentals — layout, spacing, typography, and color — are introduced with simple before-and-after examples, so you can see exactly how a small change makes an interface easier to scan and understand.',
      'Usability principles like consistency, feedback, and forgiving error states are explained with everyday app examples, because these ideas are much easier to remember once you have seen them in something you already use.',
      'The course wraps up with a short case study that walks through redesigning a cluttered screen step by step, applying everything covered in the earlier lessons.',
    ],
  },
  {
    title: 'Mastering Stripe Payments',
    description: 'Everything you need to add subscriptions and one-time payments to your app.',
    category: 'Programming',
    price: 79,
    isFree: false,
    previewImage: 'https://example.com/images/mastering-stripe.png',
    content: [
      'Stripe handles the hardest parts of accepting payments online: card storage, compliance, and fraud checks. This course starts with an overview of Stripe\'s core objects — customers, prices, and checkout sessions — and how they fit together.',
      'We build a one-time payment flow from scratch using Stripe Checkout, covering how to create a session on your server, redirect the user to Stripe\'s hosted payment page, and read back the result once they return to your app.',
      'Webhooks are where many integrations go wrong, so we spend real time on them: verifying the signature, handling the checkout.session.completed event, and updating your own database only after Stripe confirms the payment actually succeeded.',
      'Subscriptions add recurring billing on top of everything covered so far. You will learn how to create subscription prices, handle upgrades and cancellations, and keep your app in sync with a customer\'s current plan.',
      'The final lesson covers testing safely with Stripe\'s test mode and test card numbers, plus a checklist for the differences to watch for when you flip a project over to live keys.',
    ],
  },
  {
    title: 'Digital Marketing Fundamentals',
    description: 'SEO, social media, and email marketing basics for beginners.',
    category: 'Marketing',
    price: 39,
    isFree: false,
    previewImage: 'https://example.com/images/digital-marketing.png',
    content: [
      'Digital marketing covers every channel a business uses to reach people online. This course gives you a working map of the space before going deep on any one channel, so you understand how the pieces support each other.',
      'Search engine optimization is explained from the ground up: how search engines rank pages, the difference between on-page and off-page SEO, and a handful of practical changes that tend to move the needle fastest for a new site.',
      'Social media marketing is covered with a focus on picking the right platform for your audience rather than trying to be everywhere at once, along with a simple framework for planning a week of posts.',
      'Email marketing is often the highest-return channel a small business has, and this section covers building a list ethically, writing subject lines people actually open, and setting up a basic welcome sequence.',
      'The course ends by tying these channels together into a simple monthly plan, so you leave with something you can actually put to use rather than just a list of definitions.',
    ],
  },
];

async function seedCourses() {
  await connectDB();

  const admin = await User.findOne({ role: 'admin' });
  if (!admin) {
    console.error('No admin account found. Run adminSeed.js first (npm run seed:admin).');
    process.exit(1);
  }

  await Course.deleteMany({}); // keep seeding idempotent for dev/demo use

  const coursesWithCreator = sampleCourses.map((c) => ({ ...c, createdBy: admin._id }));
  await Course.insertMany(coursesWithCreator);

  console.log(`Seeded ${coursesWithCreator.length} courses.`);
  process.exit(0);
}

seedCourses().catch((err) => {
  console.error('Course seed failed:', err);
  process.exit(1);
});
